const unsigned char fontdata_6x8[12288];
