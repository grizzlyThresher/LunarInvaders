#define SHIP_WIDTH 28
#define SHIP_HEIGHT 13
const unsigned short Ship_data[364];
