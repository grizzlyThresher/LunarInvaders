#define MAINTITLE_WIDTH 240
#define MAINTITLE_HEIGHT 160
const unsigned short MainTitle_data[38400];
