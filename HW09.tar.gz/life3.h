#define LIFE3_WIDTH 22
#define LIFE3_HEIGHT 11
const unsigned short life3_data[242];
