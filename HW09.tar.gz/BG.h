#define BG_WIDTH 240
#define BG_HEIGHT 160
const unsigned short BG_data[38400];
