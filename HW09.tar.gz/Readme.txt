=================================================================================================
=================================================================================================
*Controls*
=================================================================================================
=================================================================================================

Z - Fire Energy Blast
Arrow Keys - Movement
Backspace - Return to Title Screen

=================================================================================================
=================================================================================================
*Story*
=================================================================================================
=================================================================================================

The day has finally arrived. Earth is being attacked by an unknown Alien force. Their ships are 
indestructible to all manner of Human weaponry. Humanity's only hope is to escape. And they know
this. The enemy has set up a barrier around the Earth preventing all physical materials from 
passing through while allowing the enemy ships passage from the outside. 

You are the pilot of Earth's last chance at survival, a ship outfitted with an energy cannon 
capable of producing a blast of energy that can slip through the barrier. Though the enemy ships
themselves are impervious to damage, in order to create the barrier the Alien Mothership must
make use of an exposed shield emitter. Judging from reports gathered from intelligence, the
Aliens can only keep the barrier in place for a short amount of time, about a minute, but that's
more than long enough for them to eliminate all human life on Earth.

Your mission: Destroy the emitter, thereby destroying the barrier, or survive until the barrier 
comes down. Earth has been lost, but with your effort, Humanity may survive.
