#define LIFE2_WIDTH 22
#define LIFE2_HEIGHT 11
const unsigned short life2_data[242];
