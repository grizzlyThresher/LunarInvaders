#define LIFE1_WIDTH 22
#define LIFE1_HEIGHT 11
const unsigned short life1_data[242];
