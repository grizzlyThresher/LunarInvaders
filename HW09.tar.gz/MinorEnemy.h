#define MINORENEMY_WIDTH 19
#define MINORENEMY_HEIGHT 9
const unsigned short MinorEnemy_data[171];
