#define WINSCREEN_WIDTH 240
#define WINSCREEN_HEIGHT 160
const unsigned short WinScreen_data[38400];
