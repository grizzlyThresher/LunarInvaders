#define BLUEBULLET2_WIDTH 15
#define BLUEBULLET2_HEIGHT 8
const unsigned short BlueBullet2_data[120];
